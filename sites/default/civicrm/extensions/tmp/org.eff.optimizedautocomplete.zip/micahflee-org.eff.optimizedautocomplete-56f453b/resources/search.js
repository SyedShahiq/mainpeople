(function($) {
  $(function(){
  
    $('.crm-search-setting-form-block').prepend('<p>NOTE: You have the <strong>Optimized Autocomplete extension</strong> enabled, which means settings that affect autocomplete search boxes will be ignored. However autocomplete searches should finish much faster this way.</p>');
    $('.crm-search-setting-form-block-autocompleteContactSearch').css('opacity', '.3');

  });
})(cj);
